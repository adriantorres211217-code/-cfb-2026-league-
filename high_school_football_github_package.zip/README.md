# Nationwide High School Football League Import

This package builds a GitHub-ready league JSON containing high-school football programs from every U.S. state plus Washington, D.C.

## Files

- `build_all_high_school_football.py` — nationwide builder
- `.github/workflows/build-high-school-football.yml` — GitHub Action that runs the builder and commits the generated JSON
- `high_school_football_all_usa.json` — generated game-import file
- `high_school_football_all_usa_raw_schools.json` — generated school/source data

## Use on GitHub

1. Put `build_all_high_school_football.py` in the root of your repository.
2. Put `build-high-school-football.yml` inside `.github/workflows/`.
3. Open your repository's **Actions** tab.
4. Run **Build nationwide high school football JSON**.
5. When it finishes, the generated JSON files are committed into the repository.

The game-import URL will be:

`https://raw.githubusercontent.com/YOUR-USERNAME/YOUR-REPO/main/high_school_football_all_usa.json`

Replace `YOUR-USERNAME/YOUR-REPO` with your real GitHub repo path.

## Import schema

Each team is emitted with:

- `name`
- `mascot`
- `primary`
- `secondary`
- `tertiary`
- `prestige`
- `offenseScheme`
- `defenseScheme`
- `abbreviation`
- `region`
- `logoURL`

State groups are represented as conferences so the full national set can live in one league JSON.

## Notes

The builder tries MaxPreps' Next.js school-data endpoint first and falls back to the visible state football school pages. It keeps every discovered school even if optional mascot/color metadata cannot be enriched. Real source logos/colors/rating fields are used when exposed; otherwise deterministic fallbacks keep the file valid.

A full nationwide enrichment pass can take a long time because it visits thousands of team pages. GitHub Actions is the intended place to run it.
